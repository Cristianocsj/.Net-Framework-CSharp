﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlugarQuartos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Estudante[] vect = new Estudante[10];
            Console.Write("Digite o número  de estudantes (1 a 10): ");
            int numEstudantes = int.Parse(Console.ReadLine());

            for(int i = 0; i < numEstudantes; i++)
            {
                Console.WriteLine($"\nInforme os dados do estudante {i + 1}: ");

                Console.Write("Nome: ");
                string nome = Console.ReadLine();

                Console.Write("Email: ");
                string email = Console.ReadLine();

                Console.WriteLine("Escolha um quarto (0 a 9): ");
                int quarto = int.Parse(Console.ReadLine());
                vect[quarto] = new Estudante(nome, email);
            }
            Console.WriteLine("\nQuartos Ocupados:");
            for(int i = 0;i< 10; i++)
            {
                if (vect[i] != null)
                {
                    Console.WriteLine($"Este quarto está ocupado pelo cliente {vect[i].Nome} :: {vect[i].Email}");
                }
            }
            Console.ReadKey();
        }
    }
}
