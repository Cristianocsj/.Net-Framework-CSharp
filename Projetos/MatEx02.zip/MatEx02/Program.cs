﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatEx02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Digite a ordem da matriz: ");
            int n = int.Parse(Console.ReadLine());
            int[,] mat = new int[n, n];
            int i;
            int j;
            int cont = 0;
            

            for(i = 0; i < n; i++)
            {
                for(j = 0; j < n; j++)
                {
                    Console.Write($"O valor na posição [{i}],[{j}] da matriz: ");
                    mat[i, j] = int.Parse(Console.ReadLine());

                }
            }



            Console.WriteLine("******");
            for (i = 0; i < n; ++i)
            {
                for(j=0; j < n; ++j)
                {
                    if (i == j)
                    {
                        Console.WriteLine(mat[i, j]);
                    }

                    if (mat[i, j] < 0)
                    {
                        cont = cont + 1;
                    }
                }
            }
            Console.Write("A quantidade de números negativos é " + cont);
            Console.ReadKey();
        }
    }
}
